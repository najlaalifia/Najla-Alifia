<?php
    $Email = $_POST['Email'];
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $conn = new mysqli('localhost','root', '','datauser');
    if($conn->connect_error) {
        die('Connection Failed: ' .$conn->connect_error);
    } else{
        $stmt = $conn->prepare("insert into datauser(Email, Username, Password) 
            values(?, ?, ?)");
        $stmt->bind_param("sss", $Email, $Username, $Password);
        $stmt->execute();
        echo "Succesfully...";
        $stmt->close();
        $conn->close();
}
?>